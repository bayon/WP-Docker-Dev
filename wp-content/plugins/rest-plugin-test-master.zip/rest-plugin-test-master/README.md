# rest-plugin-test
An example of REST API with React thanks to versionpress.
