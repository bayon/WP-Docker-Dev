 // Insert Javascript functions here that execute before the html is loaded.
function generic_widget_before(){
	// <code>
}
// Insert Javascript functions here that execute before the html is loaded.
function generic_widget_after(){
	// <code>
}